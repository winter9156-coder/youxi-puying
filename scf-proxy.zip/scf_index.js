'use strict';

// 幼析·育见 DeepSeek API 代理云函数
// 部署到腾讯云 SCF（Node.js 18+）
// 触发器：API 网关

const https = require('https');

exports.main_handler = async (event, context) => {
  // 从 event 中提取请求信息
  // API 网关触发时，event 结构为 { path, httpMethod, headers, body, queryString }
  const path = event.path || '';
  const method = event.httpMethod || 'GET';
  const body = event.body || '';
  
  // 只代理 /v1/chat/completions
  if (!path.includes('/v1/chat/completions')) {
    return {
      isBase64Encoded: false,
      statusCode: 404,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Not Found' }),
    };
  }

  if (method !== 'POST') {
    return {
      isBase64Encoded: false,
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  // 从环境变量读取 DeepSeek API Key（在 SCF 控制台设置）
  const apiKey = process.env.DEEPSEEK_API_KEY || '';
  if (!apiKey) {
    return {
      isBase64Encoded: false,
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'DEEPSEEK_API_KEY not configured' }),
    };
  }

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.deepseek.com',
      port: 443,
      path: path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      timeout: 60000,
    };

    const req = https.request(options, (res) => {
      let data = '';
      const contentType = res.headers['content-type'] || 'application/json';

      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        resolve({
          isBase64Encoded: false,
          statusCode: res.statusCode,
          headers: {
            'Content-Type': contentType,
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          },
          body: data,
        });
      });
    });

    req.on('error', (e) => {
      resolve({
        isBase64Encoded: false,
        statusCode: 502,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: e.message }),
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({
        isBase64Encoded: false,
        statusCode: 504,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Gateway Timeout' }),
      });
    });

    req.write(body);
    req.end();
  });
};
